/**
 * 
 * Fait par Andre-Viet Tran (p1121494) et Alexandre Keo (p0992086)
 * 
 * Date : 26 Septembre 2019
 * 
 * But :	-Tester la classe Personne
 * 			-Creer un tableau de Personne
 * 			-Afficher les informations en appelant toString()
 * 			-Afficher l'age moyen
 *
 */

public class PersonneTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Initialiser le tableau
		Personne [] population = new Personne [6];	//tableau de 6 personnes
		
		//Creer les objects du tableau
		population[0] = new Professeur("Jacques", 1980, 'M',"agr�g�", "UdeM");
		population[1] = new Professeur("Marie", 1990, 'F', "adjoint", "Concordia");
		population[2] = new Professeur("Frank", 1970, 'M', "titulaire", "McGill");
		population[3] = new EtudiantBac("Jean", 2000, 'M', "UdeM");
		population[4] = new EtudiantMaitrise("Claire", 1998, 'F', "Concordia", population[1]);
		population[5] = new EtudiantDoctorat("�ric", 1995, 'M', "McGill", population[2]);
		
		int n=0; //pour la somme
		
		//On parcourt le tableau une seule fois
		for(int i=0; i<6;i++) {
			//afficher les informations
			System.out.println(i+1 + ") " + population[i].toString());
			
			//somme total des ages
			n += population[i].age;
		}
		
		//Afficher l'age moyen
		System.out.println("\n\nL'�ge moyen de toutes ces personnes : " + n/6);
	}
}
