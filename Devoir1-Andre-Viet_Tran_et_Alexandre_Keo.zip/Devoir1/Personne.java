/**
 * Fait par Andre-Viet Tran (p1121494) et Alexandre Keo (p0992086)
 * 
 * Date : 26 septembre 2019
 * 
 * But : - creer la classe Personne (parent) avec des classes enfant
 * 		 - toString() pour faire retourner les informations
 * 
 */

import java.util.Calendar;	//pour obtenir l'annee courante

//Classe parent
class Personne {
	//protected variables
	protected String nom;
	protected int annee;
	protected char sexe;
	protected int age;	
	protected String sexeAfficher;
	
	//constructeur
	public Personne(String nom, int annee, char sexe) {
		this.nom = nom.substring(0,1).toUpperCase() + nom.substring(1);
		this.annee = annee;
		this.sexe = sexe;
		
		age = Calendar.getInstance().get(Calendar.YEAR) - annee;	//age = 2019 - annee
		
		if(sexe=='M'||sexe=='m') {
			sexeAfficher = "masculin";
		}
		else sexeAfficher = "f�minin";
	}
	
	public String toString() {
		return "\"" + nom + "\", n�(e) en " + annee + ", " + sexeAfficher;
	}
}

class Etudiant extends Personne {
	protected String uni;
	
	//constructeur
	public Etudiant(String nom, int annee, char sexe, String uni) { 
		super(nom, annee, sexe);
		this.uni=uni;
	}
	
	public String toString() {
		String msg = super.toString();
		return msg + ". On l'inscrit � \"" + uni+"\"";
	}
}

	class EtudiantBac extends Etudiant {
		public EtudiantBac(String nom, int annee, char sexe, String uni) {
			super(nom, annee, sexe, uni);
		}
		
		public String toString() {
			String msg1 = super.toString();
			return "�tudiant de Bac, " + msg1 + ".";
		}
	}
	
	class EtudiantMaitrise extends Etudiant {
		private Professeur prof;
		public EtudiantMaitrise(String nom, int annee, char sexe, 
				String uni, Personne prof) {
			super(nom, annee, sexe, uni);
			this.prof=(Professeur) prof;
		}
		
		public String toString() {
			String msg = super.toString();
			return "�tudiante en Ma�trise, " + msg + ", et l'assigne sous "
					+ "la direction la professeur \"" + prof.getName() +"\"."; 
		}
	}
	
	class EtudiantDoctorat extends Etudiant {
		private Professeur prof;
		public EtudiantDoctorat(String nom, int annee, char sexe, 
				String uni, Personne prof1) {
			super(nom, annee, sexe, uni);
			this.prof=(Professeur) prof1;
		}
		
		public String toString() {
			String msg = super.toString();
			return "�tudiant en Doctorat, " + msg + ", et on l'assigne sous "
					+ "la direction du professeur \"" + prof.getName() + "\".";
		}
	}
	
class Professeur extends Personne {
	protected String rang;
	protected String uni;
	
	//constructeur
	public Professeur(String nom, int annee, char sexe, String rang, String uni) {
		super(nom, annee, sexe);
		this.rang=rang;
		this.uni=uni;
	}
	
	public String getName()
	{	return nom;	}
	
	public String toString() {
		String msg=super.toString();
		if (sexe=='F' || sexe=='f') {
			return "Professeur(e) dont le nom est " + msg + 
					". On le nomme ensuite \"" + rang +"\" � \"" + uni+"\".";
		}
		else return "Professeur dont le nom est " + msg + 
					". On le nomme ensuite \"" + rang +"\" � \"" + uni+"\".";
	}
}